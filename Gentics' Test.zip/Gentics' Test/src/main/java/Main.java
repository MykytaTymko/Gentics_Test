import java.net.MalformedURLException;

/**
 * Starting application.
 */
class Main {

    /**
     * Main method that launch application.
     *
     * @param args
     *
     * @throws MalformedURLException
     */
    public static void main(final String[] args) throws MalformedURLException {
        new Analyzer();
    }
}
