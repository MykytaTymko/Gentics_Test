import org.junit.Test;

import java.io.IOException;
import java.sql.SQLException;

public class AnalyzerTest {

    @Test
    public void getConnection() throws SQLException, IOException, ClassNotFoundException {
        Analyzer.getConnection();
    }
}
